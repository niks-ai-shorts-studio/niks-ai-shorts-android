# Niks AI Shorts Studio — Android APK builder

This project wraps the included mobile web prototype in a basic Android WebView app. The prototype can draft multilingual scripts and scene prompts, preview available browser speech, and download text planning packs.

## Important limitation
This APK is a starter planner, **not yet a full automatic AI video renderer**. It does not currently generate actual video clips or export an MP4. Those require a further build phase and, for cloud AI features, suitable APIs/services. Free usage is not unlimited.

## Build an APK from your phone using GitHub Actions
1. Download and extract this ZIP.
2. In GitHub, create a repository named `niks-ai-shorts-android`.
3. Upload the **contents** of this folder into the repository root (including the hidden `.github` folder). If mobile upload hides `.github`, create the workflow file in GitHub's web editor at `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab. If asked, enable Actions.
5. Select **Build Android APK** → **Run workflow**. If the workflow does not appear, commit a change to `main` first.
6. Wait until the run finishes successfully. Open the completed run, scroll to **Artifacts**, and download `Niks-AI-Shorts-Studio-debug-apk`.
7. Extract the artifact ZIP on your phone. Tap `app-debug.apk` to install. Android may ask you to allow installation from your browser/file manager. Only enable this for the APK you built from your own repository, then disable it again afterward.

## Security and expectations
- This workflow builds a debug APK. It is not Play Store signed; Android can still install it manually.
- The workflow uses GitHub-hosted runners; GitHub Actions usage limits and terms apply.
- Do not add API keys to the public repository.
- Check current GitHub and Android instructions if their UI changes.
